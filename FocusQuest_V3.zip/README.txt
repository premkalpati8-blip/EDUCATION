FOCUSQUEST VERSION 3

NEW FEATURES
-------------
✔ User Profile
✔ Local Leaderboard
✔ PWA Manifest
✔ Theme Memory
✔ Local Data Persistence
✔ Firebase Integration Template

VERSION 4 IDEAS
---------------
- Real online authentication
- Cloud synced habits
- Friends system
- Daily quests
- Push notifications
- Avatar and RPG mechanics
