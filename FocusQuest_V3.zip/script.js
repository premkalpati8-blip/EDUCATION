let xp=+(localStorage.xp||0);
let streak=+(localStorage.streak||0);

function render(){
document.getElementById("xp").innerText=xp;
document.getElementById("level").innerText=Math.floor(xp/500)+1;
document.getElementById("streak").innerText=streak;
document.getElementById("welcome").innerText=
localStorage.username ? "Welcome, "+localStorage.username+"!" : "";
loadLeaderboard();
}

function saveUser(){
localStorage.username=document.getElementById("username").value;
render();
}

function addHabit(){
let n=habitName.value;
let r=parseInt(habitXP.value);
if(!n||!r)return;

let li=document.createElement("li");
let btn=document.createElement("button");
btn.innerText="Complete";

btn.onclick=()=>{
xp+=r;
streak++;
localStorage.xp=xp;
localStorage.streak=streak;
saveLeaderboard();
li.remove();
render();
};

li.innerHTML=n+" (+"+r+" XP) ";
li.appendChild(btn);
habitList.appendChild(li);
habitName.value="";
habitXP.value="";
}

function saveLeaderboard(){
let board=JSON.parse(localStorage.board||"[]");
let name=localStorage.username||"Player";
board=board.filter(x=>x.name!==name);
board.push({name:name,xp:xp});
board.sort((a,b)=>b.xp-a.xp);
localStorage.board=JSON.stringify(board.slice(0,10));
}

function loadLeaderboard(){
let board=JSON.parse(localStorage.board||"[]");
leaderboard.innerHTML=board.map(x=>"<tr><td>"+x.name+"</td><td>"+x.xp+"</td></tr>").join("");
}

function toggleTheme(){
document.body.classList.toggle("dark");
localStorage.theme=document.body.classList.contains("dark")?"dark":"light";
}

if(localStorage.theme==="dark"){document.body.classList.add("dark");}
render();
