// V3 Firebase TODO
// - Enable Google Authentication
// - Create Firestore database
// - Store habits online
// - Sync leaderboard between users
